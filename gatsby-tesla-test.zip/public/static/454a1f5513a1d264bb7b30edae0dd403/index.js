

const images = [
    { id: 1, src: '../images/sign1.png', title: 'foo', description: 'bar' },
    { id: 2, src: '../images/sign2.png', title: 'foo', description: 'bar' },
    { id: 3, src: '../images/sign3.png', title: 'foo', description: 'bar' },
    { id: 4, src: '../images/sign4.png', title: 'foo', description: 'bar' },
    { id: 5, src: '../images/sign5.png', title: 'foo', description: 'bar' },
    { id: 6, src: '../images/sign6.png', title: 'foo', description: 'bar' },
    { id: 7, src: '../images/sign7.png', title: 'foo', description: 'bar' },
    { id: 8, src: '../images/sign8.png', title: 'foo', description: 'bar' },
  ];

  export default images;

// export const First = require('./photos/first.jpg');
// export const Second = require('./photos/second.jpg');
// export const LinkedIn = require('./social/linkedin.png');